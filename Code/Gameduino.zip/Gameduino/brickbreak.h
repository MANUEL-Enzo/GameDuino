/*
 * brickbreak.h
 *
 *  Created on: 17 janv. 2020
 *      Author: Manuel Enzo
 */

#ifndef BRICKBREAK_H_
#define BRICKBREAK_H_

class brickbreak {
public:
	brickbreak();
};

#endif /* BRICKBREAK_H_ */
