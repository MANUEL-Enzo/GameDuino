/*
 * brick.h
 *
 *  Created on: 17 janv. 2020
 *      Author: Manuel Enzo
 */

#ifndef BRICK_H_
#define BRICK_H_

class brick {
public:
	brick();
};

#endif /* BRICK_H_ */
