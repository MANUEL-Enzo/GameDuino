/*
 * brick.cpp
 *
 *  Created on: 17 janv. 2020
 *      Author: Manuel Enzo
 */

#include "brick.h"

brick::brick() {
	// TODO Auto-generated constructor stub

}

